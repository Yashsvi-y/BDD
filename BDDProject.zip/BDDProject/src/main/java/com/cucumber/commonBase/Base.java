package com.cucumber.commonBase;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;


import java.io.*;
import java.util.Properties;

public class Base {
    //initialize driver
    public static WebDriver driver;
    protected Actions actions;
    protected SoftAssert softAssert;
    protected WebDriverWait wait;



    public WebDriver browserLaunch(String browser) throws IOException {
        if (browser.equalsIgnoreCase("chrome")) {
            driver = new ChromeDriver();
        } else if (browser.equalsIgnoreCase("firefox")) {
            driver = new FirefoxDriver();
        } else if (browser.equalsIgnoreCase("edge")) {
            driver = new EdgeDriver();
        }
        return driver;
    }

    public String readPropertiesFile(String property) throws IOException {
        FileReader fileReader = new FileReader("src/test/resources/config.properties");

        Properties prop = new Properties();
        prop.load(fileReader);
        return prop.getProperty(property);
    }
}


