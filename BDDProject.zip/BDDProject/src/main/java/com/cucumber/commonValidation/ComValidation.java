package com.cucumber.commonValidation;

public class ComValidation {
    public static final String IMAGEPNG="image/png";
}
