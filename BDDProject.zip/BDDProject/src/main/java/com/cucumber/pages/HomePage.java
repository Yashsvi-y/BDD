package com.cucumber.pages;


import com.cucumber.commonBase.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;


public class HomePage extends Base
{

    public void openWebsite(){

        driver.get("https://www.kapruka.com/online/chocolates");
    }

    public void clickAccount() {

        driver.findElement(By.xpath("//a[normalize-space()='Your Account']")).click(); //using Selenium click button method
    }

    public void insertUsername()
    {
        driver.findElement(By.xpath("//a[normalize-space()='Your Account']")).click(); //using Selenium click button method
    }
    }
